import arcpy
dataset = r'D:\Arcpy_workshop\Lab-8\Data\Gadag.gdb\Road'

spatialref = arcpy.Describe(dataset).spatialReference
mapdoc = arcpy.mapping.MapDocument(r'D:\Arcpy_workshop\Lab-8\Map.mxd')
for df in arcpy.mapping.ListDataFrames(mapdoc):
    df.spatialReference = spatialref
    df.scale = 24000
    
del mapdoc


