import arcpy
mapdoc = arcpy.mapping.MapDocument("Current")
listdf = arcpy.mapping.ListDataFrames(mapdoc)
for df in listdf:
    print df.name
    
del mapdoc

