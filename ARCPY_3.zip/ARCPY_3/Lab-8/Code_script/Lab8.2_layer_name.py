import arcpy
mapdoc = arcpy.mapping.MapDocument("CURRENT")
dflist = arcpy.mapping.ListDataFrames(mapdoc)
lyrlist = arcpy.mapping.ListLayers(mapdoc,"",dflist[0])
for lyr in lyrlist:
    print lyr.name
    
del mapdoc
