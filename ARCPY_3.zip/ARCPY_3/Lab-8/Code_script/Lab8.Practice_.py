import arcpy
mapdoc = arcpy.mapping.MapDocument(r'D:\Arcpy_workshop\Lab-8\Map.mxd')
arcpy.mapping.ExportToJPEG(mapdoc,r'D:\Arcpy_workshop\Lab-8\Data\map.JPEG')
arcpy.mapping.ExportToBMP(mapdoc,r'D:\Arcpy_workshop\Lab-8\Data\map.BMP')
arcpy.mapping.ExportToPDF(mapdoc,r'D:\Arcpy_workshop\Lab-8\Data\map.PDF')
arcpy.mapping.ExportToSVG(mapdoc,r'D:\Arcpy_workshop\Lab-8\Data\map.SVG')
arcpy.mapping.ExportToPDF(mapdoc,r'D:\Arcpy_workshop\Lab-8\Data\map.PDF')

