import arcpy
from arcpy import env 
env.workspace = r'D:\Arcpy_workshop\Lab-7\Output.gdb'
data = r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif'
slope = arcpy.sa.Slope(data)


