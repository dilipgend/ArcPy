import arcpy
raster = r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif'
desc = arcpy.Describe(raster)
print desc.dataType
print desc.bandCount
print desc.compressionType

