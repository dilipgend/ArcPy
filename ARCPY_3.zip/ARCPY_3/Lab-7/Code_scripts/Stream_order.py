import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Practice.gdb'
arcpy.sa.slope(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
slope = arcpy.sa.Slope(r'D:\Arcpy_workshop\Lab-7\Data\DEM.img.xml')
slope = arcpy.sa.Slope(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
arcpy.sa.Hillshade(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
hillshade = arcpy.sa.Hshade(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
hlshade = arcpy.sa.Hillshade(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
Fill = arcpy.sa.Fill(r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif')
aspect = arcpy.sa.Aspect("Fill")
fldir = arcpy.sa.FlowDirection("Fill")
flacc = arcpy.sa.FlowAccumulation("fldir","Fill")
Strorder = arcpy.sa.StreamOrder("flacc","fldir")
convert = arcpy.RasterToPolyline_conversion("Strorder")
convert1 = arcpy.RasterTopol("Strorder")
