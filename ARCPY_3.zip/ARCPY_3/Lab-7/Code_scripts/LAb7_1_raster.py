import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-7\Data'
rasterlist = arcpy.ListRasters()
for raster in rasterlist:
    print(raster)
    

