import arcpy
from arcpy import env
from arcpy.sa import*
env.workspace =  r'D:\Arcpy_workshop\Lab-7\Data\n16_e074_3arc_v1.tif'
myremap = RemapRange([[1,200,0],[200,400,1],[400,600,2],[600,800,3],[800,1030]])
outreclass = Reclassify("n16_e074_3arc_v1.tif","Value",myremap)

outreclass.save(r'D:\Arcpy_workshop\Lab-7\Output.gdb\Reclass_raster')


