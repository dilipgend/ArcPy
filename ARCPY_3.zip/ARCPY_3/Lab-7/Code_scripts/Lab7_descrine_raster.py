import arcpy
raster = r'D:\Arcpy_workshop\Lab-7\Data\KSRDPR_DEM.tif'
desc = arcpy.Describe(raster)
print desc.height
print desc.isinteger
print desc.meancellheight
print desc.meancellwidth
print desc.nodatavalue
print desc.pixeltype
print desc.pyramidfield
print desc.primaryfield
print desc.tabletype
print desc.width

