import arcpy
raster = r'F:\Change detection-Sasi\1997_gm_classified.img'
desc = arcpy.Describe(raster)
print desc.dataType
print desc.bandCount
print desc.compressionType

