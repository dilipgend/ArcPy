import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-6\Output.gdb'
cordlist = [[17.0,78.0],[21.0,85.0],[18.0,87.0]]

pointlist = []
for x, y in cordlist:
    point = arcpy.Point(x,y)
    pointgeometry = arcpy.PointGeometry(point)
    pointlist.append(pointgeometry)
    
arcpy.Buffer_analysis(pointlist,"Buffer.shp","10 Meters")

