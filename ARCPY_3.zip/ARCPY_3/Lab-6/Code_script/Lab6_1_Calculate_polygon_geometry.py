import arcpy
data = 'Houses'
field = "Area"
Expre = "!shape.area!"
arcpy.CalculateField_management(data,field,Expre,"PYTHON")

