import arcpy
fc = r'D:\Arcpy_workshop\Lab-6\Data\Gadag.gdb\Landmark'
cursor = arcpy.da.SearchCursor(fc,["SHAPE@XY"])
for row in cursor:
    x,y = row[0]
    print"{0},{1}".format(x,y)
    

