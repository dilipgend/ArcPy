import arcpy
fc = 'Roads'                                 
cursor = arcpy.da.SearchCursor(fc,["Length"])


for row in cursor:
    print "Street Length = {0}".format(row[0])
    

