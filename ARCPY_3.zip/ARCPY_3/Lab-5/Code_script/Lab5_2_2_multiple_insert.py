import arcpy
fc = 'Roads'
cursor = arcpy.da.InsertCursor(fc , ["Length"])
x = 1
while x<6:
    cursor.insertRow([143])
    x+=1
    
del cursor

