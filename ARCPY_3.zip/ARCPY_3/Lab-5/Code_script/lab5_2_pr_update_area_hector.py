import arcpy
fc = 'Building'
cursor = arcpy.da.UpdateCursor(fc,["Hectors","Acres"])
for row in cursor:
    row[0] = row[1]/2.5
    cursor.updateRow(row)
    
del cursor

