import arcpy
fc = 'Building'
cursor = arcpy.da.InsertCursor(fc, ["OBJECTID"])
x = 1
while x<11:
    cursor.insertRow([2106655])
    x+=1
    
del cursor

