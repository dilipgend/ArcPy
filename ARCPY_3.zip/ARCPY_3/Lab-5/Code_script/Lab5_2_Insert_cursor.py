import arcpy
fc = r'D:\Arcpy_workshop\Lab-5\Data\NCR.gdb\Roads'
cursor = arcpy.da.InsertCursor(fc , ["Length"])
cursor.insertRow([88])
64L
del cursor


