import arcpy
fc = r'D:\Arcpy_workshop\Lab-5\Data\NCR.gdb\Consumer'
cursor = arcpy.da.SearchCursor(fc,["Consumer_N","House_No"])


for row in cursor:
    print "Consumer name House no =  {0}".format(row[0:6] [0:6])
    

