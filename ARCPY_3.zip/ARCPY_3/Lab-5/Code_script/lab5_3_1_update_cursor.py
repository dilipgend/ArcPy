import arcpy
fc = 'Building'
cursor = arcpy.da.UpdateCursor(fc , ["Acres","Shape_Area"])
for row in cursor:
    row[0] = row[1]/43560
    cursor.updateRow(row)
    
del cursor

