import arcpy
fc = 'Consumer'
cursor = arcpy.da.UpdateCursor(fc , ["Meter_make"])
for row in cursor:
    if row[0] == ("SARAF INDUSTRIES (BHUTINDA)"):
        cursor.deleteRow()
        
DEL cursor
