import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-4\Output.gdb'
arcpy.MultipleRingBuffer_analysis("Pole selection","Pole_S_Buffer",[20,40,80,120],"Meters"," ","ALL")

