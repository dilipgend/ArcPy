import arcpy 
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Output.gdb'
arcpy.Buffer_analysis(r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Data\Delhi.gdb\Dataset\Meter','Buffer_analysis',"80 Meter")


