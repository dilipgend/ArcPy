import arcpy
from arcpy import env
env.workspace = r'D:\Lab-1-2\Lab-2\Data\New File Geodatabase.gdb'
arcpy.SplitByAttributes_analysis("Roads",env.workspace,"highway")


import arcpy
from arcpy import env
env.workspace = r'D:\Lab-1-2\Lab-2\Data\New File Geodatabase.gdb'
arcpy.SplitByAttributes_analysis("Roads",env.workspace,"highway")

import arcpy
from arcpy import env
env.workspace = r'D:\Lab-1-2\Lab-2\Data\New File Geodatabase.gdb'
arcpy.SplitByAttributes_analysis("Roads",env.workspace,"highway")


