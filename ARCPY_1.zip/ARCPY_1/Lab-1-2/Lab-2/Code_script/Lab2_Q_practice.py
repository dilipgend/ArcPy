import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Output.gdb'

arcpy.Buffer_analysis(r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Output.gdb\Mysuru_Roads',"Buffer_Roads","40 Meters")


