a = 0
address = "Manakarnwadi, Po. Pimpri,    Tahsil. Man, Dist. Satara, State Maharashtra,Postal code: 415540. India."

       
while a<6:
    print(a,address)
    a+=1
    

