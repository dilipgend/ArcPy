import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Output.gdb'
arcpy.SplitByAttributes_analysis("Roads",env.workspace,"highway")


