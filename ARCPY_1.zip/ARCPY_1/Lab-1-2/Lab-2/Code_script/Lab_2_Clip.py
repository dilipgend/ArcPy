import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Output.gdb'
arcpy.Clip_analysis(r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Data\Delhi.gdb\Dataset\Roads',r'D:\Arcpy_workshop\Lab-1-2\Lab-2\Data\Delhi.gdb\Dataset\Sector','clip_roads')


