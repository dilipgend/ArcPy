Name = "Gend Dilip Dasharath"
Address = "At.Manakrnwadi, Po.Pimpari, Tahsil.Man,Dist.Satara,Maharastra" 
U_name = "JSS ACADEMY OF HIGHER EDUCATION AND REASEARCH,MYSURU"
Subjects = "1. Advanced Remote Sensing \n2. Advanced GIS \n3. Web GIS \n4.Natural Resource Management \n5. Project Management" 

print Name

print Address
print U_name
print Subjects

