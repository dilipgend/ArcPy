print("hi")
for in range(10):
for i in range(10):
    print(i)
    

print("hi jack")
count = 0
count

x= 1
y = 2
print(y+x)

for count in range(1,5):
    print(count)
    

