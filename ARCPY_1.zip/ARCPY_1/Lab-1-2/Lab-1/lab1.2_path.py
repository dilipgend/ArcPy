import arcpy
arcpy.GetCount_management(r'D:\Arcpy_workshop\ArcPy.gdb-20221121T041257Z-001\ArcPy.gdb\Class\Meter')
import arcpy
arcpy.GetCount_management('Meter')

import arcpy
arcpy.GetCount_management('Roads')

import arcpy
arcpy.GetCount_management('Roads')


