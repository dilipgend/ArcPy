a = 518
b = 910
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(b/a)

