print("Dilip")
age = 23
age
c ="Dilip"
b= 23
print(c)
print(b)



for i in range(21):
    print(i)
    
print(list(i))
print([i])
for i in range(10):
    print(i,end" ")
    
name = "Dilip"
for i in range(name):
    print(i)
    
print("Dilip \n Jss")
name = "Dilip"
for i in name:
    print(i)
    

