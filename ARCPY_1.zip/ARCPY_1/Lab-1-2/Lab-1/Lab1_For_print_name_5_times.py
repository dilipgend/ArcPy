for i in range(5):
    print("Gend Dilip Dasharath")
    

