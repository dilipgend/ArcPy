print 23+52
a = 55
b = 65
print a+b
c = a+b
print c

