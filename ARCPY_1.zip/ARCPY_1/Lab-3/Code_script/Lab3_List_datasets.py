import arcpy

from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-3\Output.gdb'
env.workspace = r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset'
fcList = arcpy.ListFeatureClasses()
for fc in fcList:
    print(fc)
    

