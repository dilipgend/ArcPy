import arcpy
arcpy.env.workspace = r'D:\Arcpy_workshop\Lab-3\Output.gdb'
fc = r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Building'
if arcpy.Exists(fc):
    print("Yes this feature Class in Exist in your system")
    

