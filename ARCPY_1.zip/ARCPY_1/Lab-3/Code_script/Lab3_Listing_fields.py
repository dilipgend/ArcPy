import arcpy

from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-3\Output.gdb'
env.workspace = r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset'
fcList = arcpy.ListFeatureClasses()
for fc in fcList:
    print("Feature Class: "fc)
    
import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset'
Fields = arcpy.ListFields(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Landmark')
for field in Fields:
    print(field.name)
    

