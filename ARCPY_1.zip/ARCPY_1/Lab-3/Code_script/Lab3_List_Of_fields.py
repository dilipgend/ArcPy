import arcpy
from arcpy import env
env.workspace = r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset'
Fields = arcpy.ListFields(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Meter',r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Building',r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Roads')
for field in Fields:
    print(field.name)
    
Fields = arcpy.ListFields(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Meter')
for field in Fields:
    print(field.name)
    
Fields = arcpy.ListFields(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Building')
for field in Fields:
    print(field.name)
    
Fields = arcpy.ListFields(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Roads')
for field in Fields:
    print(field.name)
    

