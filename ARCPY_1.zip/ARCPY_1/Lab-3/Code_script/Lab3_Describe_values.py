import arcpy
desc = arcpy.Describe(r'D:\Arcpy_workshop\Lab-3\Lab-3\Data\Delhi.gdb\Dataset\Pole')
print "Feature Type:  "+desc.featureType
print "Shape Type:  "+desc.shapeType
print "Spatial Index:  "+str(desc.hasSpatialIndex)



